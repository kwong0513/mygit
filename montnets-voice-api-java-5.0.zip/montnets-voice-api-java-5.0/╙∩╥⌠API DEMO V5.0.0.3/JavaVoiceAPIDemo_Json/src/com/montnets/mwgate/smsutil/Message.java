package com.montnets.mwgate.smsutil;

/**
 * @功能概要： 语音请求实体类
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
public class Message
{
	// 用户账号
	private String	userid;

	// 用户密码
	private String	pwd;

	//手机号
	private String	mobile;

	// 语音内容
	private String	content;

	// 时间戳,格式为:MMDDHHMMSS,即月日时分秒,定长10位,月日时分秒不足2位时左补0.时间戳请获取您真实的服务器时间,不要填写固定的时间,否则pwd参数起不到加密作用
	private String	timestamp;

	//回拨显示的号码，目前需要备案后才能支持使用，如果没有备案将会返回错误码 -401094
	private String	exno;

	// 该条短信在您业务系统内的用户自定义流水编号，比如订单号或者短信发送记录的流水号。填写后发送状态返回值内将包含这个ID.最大可支持64位的字符串
	private String	custid;

	// 语音模版编号
	private String	tmplid;
	
	//消息类型
	//1：语音验证码
	//3：语音通知（语音id）
	private String msgtype;
	
	// 获取状态报告的最大条数
	private Integer	retsize;

	public String getUserid()
	{
		return userid;
	}

	public void setUserid(String userid)
	{
		this.userid = userid;
	}

	public String getPwd()
	{
		return pwd;
	}

	public void setPwd(String pwd)
	{
		this.pwd = pwd;
	}

	public String getMobile()
	{
		return mobile;
	}

	public void setMobile(String mobile)
	{
		this.mobile = mobile;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(String timestamp)
	{
		this.timestamp = timestamp;
	}

	public String getExno()
	{
		return exno;
	}

	public void setExno(String exno)
	{
		this.exno = exno;
	}

	public String getCustid()
	{
		return custid;
	}

	public void setCustid(String custid)
	{
		this.custid = custid;
	}

	public Integer getRetsize()
	{
		return retsize;
	}

	public void setRetsize(Integer retsize)
	{
		this.retsize = retsize;
	}

	public String getTmplid() {
		return tmplid;
	}

	public void setTmplid(String tmplid) {
		this.tmplid = tmplid;
	}

	public String getMsgtype() {
		return msgtype;
	}

	public void setMsgtype(String msgtype) {
		this.msgtype = msgtype;
	}

}
